<?php

//Usando la instrucción ```echo``` crea un programa en PHP que muestre el mensaje: ```Hola, Mundo!```  Optativo. Muéstralo en cursiva.
echo "<i>Hola mundo</i> <br/>";
    
//Crea un programa en PHP que guarde en una variable tu nombre y lo muestre en negrita formando el siguiente mensaje: Bienvenido tunombre
$nombre = "Aitor";
echo "Bienvenido <strong>".$nombre."</strong>";

?>