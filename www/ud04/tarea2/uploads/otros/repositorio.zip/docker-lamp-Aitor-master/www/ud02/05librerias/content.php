<?php
    function content() {
?>

<div id="content">
	<h2>Welcome to our website</h2>
	<p> This is the DIV with ID content</p>
</div>

<?php
    }
?>